ODGADNIJ FLAGĘ — NEON 2.0

Rozpakuj ZIP i otwórz index.html w przeglądarce.
Ten jeden plik zawiera całą grę, wszystkie 195 flag i grafikę. Nie wymaga internetu.

Hosting / GitHub Pages: wgraj index.html do katalogu głównego strony.

Zasady: 20 sekund na pytanie, 3 życia, +3 punkty za poprawną odpowiedź,
jedna zamiana flagi na grę. Wyniki zapisują się na urządzeniu.

Źródła i wersja instalowana PWA:
https://github.com/katarzynaekasicka-eng/odgadnij-flage
